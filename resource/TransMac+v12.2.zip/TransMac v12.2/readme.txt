安装完“TransMac v12.2”后，
	用“crack”里的“TransMac.exe”去替换安装目录的“TransMac.exe”
		就可以了